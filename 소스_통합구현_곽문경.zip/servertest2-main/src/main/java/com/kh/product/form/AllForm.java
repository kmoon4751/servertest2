package com.kh.product.form;

import lombok.Data;

@Data
public class AllForm {
  private Long pid;
  private String pname;
}
