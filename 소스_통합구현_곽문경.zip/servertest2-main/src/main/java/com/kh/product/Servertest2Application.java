package com.kh.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servertest2Application {

	public static void main(String[] args) {
		SpringApplication.run(Servertest2Application.class, args);
	}

}
